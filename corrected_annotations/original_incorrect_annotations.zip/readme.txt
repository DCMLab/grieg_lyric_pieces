Original annotation files by Adrian Nagel
Renamed using the scheme
	op12No1.txt => op12n01.txt
Changed German B and b to Bb and bb
Changed German H and h to B and b