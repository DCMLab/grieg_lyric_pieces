import os, re

dir = "/e/Documents/DCML/Grieg/Annotations"

for file in os.listdir(dir):
    #if file.endswith(".txt") or file.endswith(".log"):
    os.chdir(dir)
    m = re.search(r'op(\d*)No(\d*)(.*)',file)
    if m:
        neu = "op%dn%02d%s" % (int(m.group(1)),int(m.group(2)),m.group(3))
        os.rename(file,neu)
        print(file + " => " + neu)
        #print(os.path.join(dir,file))

ma = re.search(r'_new',"op12No5_new.log")

m.group(0)

for file in os.listdir(dir):
    if re.search(r'_new',file):
        print(file)

[os.rename(f, f.replace('_', '-')) for f in os.listdir(dir) if if file.endswith("_new.txt")]
